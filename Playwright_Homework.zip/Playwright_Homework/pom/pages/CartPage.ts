import { Page } from '@playwright/test';

export class CartPage {
    readonly page: Page;

    /*
    * We could define the type of checkoutButton as Locator
    * Ex:
    * readonly checkoutButton: Locator; (Since Locator is a type provided by Playwright)
    * Please apply this to all other page objects
    * */
    readonly checkoutButton;

    constructor(page: Page) {
        this.page = page;
        this.checkoutButton = page.locator('#checkout');
    }

    /*
    * Make sure each async function / normal function has to define a return type
    * Ex:
    * async proceedToCheckout(): Promise<void>
    * Since this function does not return any value, we use void as the return type
    * Please apply this to all other function
    * */
    async proceedToCheckout() {
        await this.checkoutButton.click();
    }
}
